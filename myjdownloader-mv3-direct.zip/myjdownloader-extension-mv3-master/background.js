'use strict';

console.log("Background: Starting MyJDownloader MV3...");

// Key strings must match StorageService.settingsKeys values
const STORAGE_KEYS = {
 CLICKNLOAD_ACTIVE: 'CLICKNLOAD_ACTIVE',
 CONTEXT_MENU_SIMPLE: 'CONTEXT_MENU_SIMPLE',
 DEFAULT_PREFERRED_JD: 'DEFAULT_PREFERRED_JD'
};

const DEVICE_TYPES = {
 ASK_EVERY_TIME: { id: 'AskEveryTimeDevice', name: 'Ask every time' },
 LAST_USED: { id: 'LastUsedDevice', name: 'Last Used' }
};

let state = {
 isConnected: false,
 devices: [],
 selectedDevice: null
};

let settings = {};

// ============================================================
// Request queue - per-tab link storage for toolbar add-links flow
// ============================================================
let requestQueue = {};
let requestIDCounter = 0;

const QUEUE_STORAGE_KEY = 'myjd_request_queue';

async function restoreRequestQueue() {
 try {
  const result = await chrome.storage.session.get(QUEUE_STORAGE_KEY);
  if (result[QUEUE_STORAGE_KEY]) {
   requestQueue = result[QUEUE_STORAGE_KEY];
   console.log('Background: Restored request queue from session storage');
  }
 } catch (e) {
  console.error('Background: Failed to restore queue:', e);
 }
}

function persistQueue() {
 chrome.storage.session.set({ [QUEUE_STORAGE_KEY]: requestQueue }).catch(err => {
  console.error('Background: Failed to persist queue:', err);
 });
}

let queueReady = restoreRequestQueue();

// Make chrome.storage.session accessible from content scripts (for myjdCaptchaSolver.js)
chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

// ============================================================
// MYJD CAPTCHA CSP rule management
// ============================================================
function addCspStrippingRule(tabId) {
 let ruleId = 10000 + tabId;
 chrome.declarativeNetRequest.updateSessionRules({
  addRules: [{
   id: ruleId,
   priority: 1,
   action: {
    type: 'modifyHeaders',
    responseHeaders: [
     { header: 'Content-Security-Policy', operation: 'remove' },
     { header: 'Content-Security-Policy-Report-Only', operation: 'remove' },
     { header: 'X-Content-Security-Policy', operation: 'remove' }
    ]
   },
   condition: {
    tabIds: [tabId],
    resourceTypes: ['main_frame', 'sub_frame', 'script', 'xmlhttprequest']
   }
  }]
 }).catch(function(err) {
  console.error('Background: Failed to add CSP stripping rule for tab', tabId, err);
 });
}

function removeCspStrippingRule(tabId) {
 let ruleId = 10000 + tabId;
 chrome.declarativeNetRequest.updateSessionRules({
  removeRuleIds: [ruleId]
 }).catch(function(err) {
  console.error('Background: Failed to remove CSP stripping rule for tab', tabId, err);
 });
}

async function addLinkToRequestQueue(link, tab) {
 await queueReady;
 let tabKey = String(tab.id);
 let time = Date.now();
 let id = "" + tab.id + time + Math.floor(Math.random() * 10000);
 if (!requestQueue[tabKey]) {
  requestQueue[tabKey] = [];
 }
 let newLink = {
  id: id,
  time: time,
  parent: { url: tab.url, title: tab.title, favIconUrl: tab.favIconUrl },
  content: link,
  type: "link"
 };

 // Check for duplicates
 let isDupe = false;
 for (let item of requestQueue[tabKey]) {
  if (item.type === newLink.type && item.content === newLink.content) {
   isDupe = true;
   break;
  }
 }

 if (!isDupe) {
  requestQueue[tabKey].push(newLink);
  persistQueue();
  notifyContentScript(tab.id);
 }
}

// Send toolbar messages to content script, injecting it first if needed
function notifyContentScript(tabId) {
 // open-in-page-toolbar -> content script (shows/creates iframe)
 chrome.tabs.sendMessage(tabId, { action: "open-in-page-toolbar", tabId: tabId })
  .catch(() => {
   // Content script not loaded — inject it, then retry
   console.log("Background: Injecting toolbar content script into tab", tabId);
   chrome.scripting.executeScript({
    target: { tabId: tabId },
    files: ['contentscripts/toolbarContentscript.js']
   }).then(() => {
    setTimeout(() => {
     chrome.tabs.sendMessage(tabId, { action: "open-in-page-toolbar", tabId: tabId }).catch(e => {
      console.error("Background: Failed to notify content script after injection:", e);
     });
    }, 100);
    // Delayed link-info-update for freshly created iframe (Angular bootstrap time)
    setTimeout(() => {
     chrome.runtime.sendMessage({ action: "link-info-update", tabId: tabId }).catch(() => {});
    }, 500);
   }).catch(e => {
    console.error("Background: Failed to inject toolbar content script:", e);
   });
  });

 // link-info-update -> all extension contexts (toolbar iframe's ToolbarController listens via chrome.runtime.onMessage)
 chrome.runtime.sendMessage({ action: "link-info-update", tabId: tabId }).catch(() => {});
}

function addPageToRequestQueue(tab) {
 if (tab && tab.url) {
  addLinkToRequestQueue(tab.url, tab);
 }
}

// ============================================================
// Offscreen document management
// ============================================================
let offscreenDocumentPath = 'offscreen.html';

async function hasOffscreenDocument() {
 const existingContexts = await chrome.runtime.getContexts({
  contextTypes: ['OFFSCREEN_DOCUMENT']
 });
 return existingContexts.length > 0;
}

async function createOffscreenDocument() {
 if (await hasOffscreenDocument()) {
  return;
 }
 console.log("Background: Creating offscreen document...");
 await chrome.offscreen.createDocument({
  url: offscreenDocumentPath,
  justification: 'MyJDownloader API operations require DOM access',
  reasons: ['LOCAL_STORAGE']
 });
 console.log("Background: Offscreen document created");
}

async function closeOffscreenDocument() {
 if (!await hasOffscreenDocument()) {
  return;
 }
 await chrome.offscreen.closeDocument();
 console.log("Background: Offscreen document closed");
}

async function sendToOffscreen(action, data = {}) {
 await createOffscreenDocument();
 return new Promise((resolve) => {
  chrome.runtime.sendMessage({
   target: 'offscreen',
   action: action,
   ...data
  }, (response) => {
   if (chrome.runtime.lastError) {
    console.error("Background: Offscreen error:", chrome.runtime.lastError.message);
    resolve({ error: chrome.runtime.lastError.message });
   } else {
    resolve(response || {});
   }
  });
 });
}

// ============================================================
// Badge and settings
// ============================================================
function updateBadge() {
 let text = state.isConnected ? "" : "!";
 chrome.action.setBadgeText({ text: text });
 chrome.action.setBadgeBackgroundColor({ color: "#f3d435" });
}

async function initSettings() {
 const result = await chrome.storage.local.get(Object.values(STORAGE_KEYS));

 settings[STORAGE_KEYS.CLICKNLOAD_ACTIVE] = result[STORAGE_KEYS.CLICKNLOAD_ACTIVE] ?? true;
 settings[STORAGE_KEYS.CONTEXT_MENU_SIMPLE] = result[STORAGE_KEYS.CONTEXT_MENU_SIMPLE] ?? true;
 settings[STORAGE_KEYS.DEFAULT_PREFERRED_JD] = result[STORAGE_KEYS.DEFAULT_PREFERRED_JD] || DEVICE_TYPES.ASK_EVERY_TIME;

 if (settings[STORAGE_KEYS.CLICKNLOAD_ACTIVE]) {
  addCnlInterceptor();
 }

 initMenuItems();
 updateBadge();
}


// ============================================================
// Direct-send mode for context menu (restores old MV2 behavior)
// Right click -> MyJDownloader cloud -> selected/last/first device
// ============================================================
const DIRECT_SEND_ENABLED = true;
const DIRECT_SEND_STORAGE_KEYS = {
 ADD_LINK_CACHED_OPTIONS: 'ADD_LINK_CACHED_OPTIONS',
 CACHED_DEVICE_LIST: 'CACHED_DEVICE_LIST',
 DEFAULT_AUTOSTART: 'DEFAULT_AUTOSTART',
 DEFAULT_AUTOEXTRACT: 'DEFAULT_AUTOEXTRACT',
 DEFAULT_PRIORITY: 'DEFAULT_PRIORITY'
};

function showDirectSendFeedback(message, isError = false) {
 console.log('Background direct-send:', message);
 try {
  chrome.action.setBadgeText({ text: isError ? '!' : 'OK' });
  chrome.action.setBadgeBackgroundColor({ color: isError ? '#d93025' : '#188038' });
  setTimeout(updateBadge, 2500);
 } catch(e) {}
 if (chrome.notifications && chrome.notifications.create) {
  chrome.notifications.create({
   type: 'basic',
   iconUrl: 'images/icon128.png',
   title: isError ? 'MyJDownloader - erreur' : 'MyJDownloader',
   message: message
  }).catch(() => {});
 }
}

function isRealDevice(device) {
 return device && device.id &&
  device.id !== DEVICE_TYPES.ASK_EVERY_TIME.id &&
  device.id !== DEVICE_TYPES.LAST_USED.id &&
  device.id !== 'SaveForLaterDevice';
}

async function getDevicesForDirectSend() {
 let result = await sendToOffscreen('offscreen-get-devices');
 if (result && result.success && Array.isArray(result.devices)) {
  await chrome.storage.local.set({ [DIRECT_SEND_STORAGE_KEYS.CACHED_DEVICE_LIST]: result.devices });
  return result.devices;
 }
 // Fallback to cached list if the cloud call is slow or temporarily fails.
 let cached = await chrome.storage.local.get(DIRECT_SEND_STORAGE_KEYS.CACHED_DEVICE_LIST);
 return cached[DIRECT_SEND_STORAGE_KEYS.CACHED_DEVICE_LIST] || [];
}

async function resolveDirectSendDevice() {
 const stored = await chrome.storage.local.get([
  STORAGE_KEYS.DEFAULT_PREFERRED_JD,
  DIRECT_SEND_STORAGE_KEYS.ADD_LINK_CACHED_OPTIONS,
  DIRECT_SEND_STORAGE_KEYS.CACHED_DEVICE_LIST
 ]);
 const preferred = stored[STORAGE_KEYS.DEFAULT_PREFERRED_JD];
 const cachedOptions = stored[DIRECT_SEND_STORAGE_KEYS.ADD_LINK_CACHED_OPTIONS];
 const devices = await getDevicesForDirectSend();
 if (!devices || devices.length === 0) throw new Error('Aucun appareil JDownloader trouvé. Vérifie que ton serveur JDownloader est connecté à MyJDownloader.');

 let wantedId = null;
 if (isRealDevice(preferred)) wantedId = preferred.id;
 else if (preferred && preferred.id === DEVICE_TYPES.LAST_USED.id && cachedOptions && isRealDevice(cachedOptions.device)) wantedId = cachedOptions.device.id;
 else if (cachedOptions && isRealDevice(cachedOptions.device)) wantedId = cachedOptions.device.id;

 if (wantedId) {
  const match = devices.find(d => d.id === wantedId);
  if (match) return match;
 }
 // If setting is still "Ask every time", direct mode can't ask from a service worker.
 // Choose the first available device, which is the behavior Alex wants for server usage.
 return devices[0];
}

function normalizeDirectSendValue(value) {
 if (!value || value === 'unset') return undefined;
 if (typeof value === 'object') {
  if (value.value !== undefined) return value.value;
  if (value.id !== undefined) return value.id;
 }
 return value;
}

async function sendLinksDirectlyToJDownloader(links, tab) {
 const cleanedLinks = (Array.isArray(links) ? links : [links])
  .map(v => (v || '').trim())
  .filter(Boolean)
  .join('\n');
 if (!cleanedLinks) throw new Error('Aucun lien à envoyer.');

 const device = await resolveDirectSendDevice();
 const opts = await chrome.storage.local.get([
  DIRECT_SEND_STORAGE_KEYS.DEFAULT_AUTOSTART,
  DIRECT_SEND_STORAGE_KEYS.DEFAULT_AUTOEXTRACT,
  DIRECT_SEND_STORAGE_KEYS.DEFAULT_PRIORITY
 ]);
 const query = {
  links: cleanedLinks,
  packageName: tab && tab.title ? tab.title : undefined,
  autostart: normalizeDirectSendValue(opts[DIRECT_SEND_STORAGE_KEYS.DEFAULT_AUTOSTART]),
  autoExtract: normalizeDirectSendValue(opts[DIRECT_SEND_STORAGE_KEYS.DEFAULT_AUTOEXTRACT]),
  priority: normalizeDirectSendValue(opts[DIRECT_SEND_STORAGE_KEYS.DEFAULT_PRIORITY])
 };
 Object.keys(query).forEach(k => query[k] === undefined && delete query[k]);
 const result = await sendToOffscreen('offscreen-add-link', { deviceId: device.id, query });
 if (!result || result.success !== true) {
  throw new Error((result && (result.error || result.message)) || 'Envoi refusé par MyJDownloader.');
 }
 await chrome.storage.local.set({
  [DIRECT_SEND_STORAGE_KEYS.ADD_LINK_CACHED_OPTIONS]: { device: device }
 });
 return { device, result };
}

async function handleDirectContextSend(info, tab) {
 try {
  let link = info.linkUrl || info.srcUrl || info.selectionText || (tab && tab.url);
  const result = await sendLinksDirectlyToJDownloader(link, tab);
  showDirectSendFeedback('Lien envoyé vers ' + (result.device.name || 'JDownloader'));
 } catch (e) {
  console.error('Background: direct context send failed:', e);
  showDirectSendFeedback(e.message || String(e), true);
  // Safety fallback: keep old toolbar queue available if direct mode fails.
  try {
   if (info.selectionText) addLinkToRequestQueue(info.selectionText, tab);
   else if (info.linkUrl) addLinkToRequestQueue(info.linkUrl, tab);
   else if (info.srcUrl) addLinkToRequestQueue(info.srcUrl, tab);
   else addPageToRequestQueue(tab);
  } catch (_) {}
 }
}

function initMenuItems() {
 chrome.contextMenus.removeAll();
 if (settings[STORAGE_KEYS.CONTEXT_MENU_SIMPLE]) {
  chrome.contextMenus.create({
   id: "simple_menu_item",
   title: "Download with JDownloader",
   contexts: ["link", "page", "selection", "image", "video", "audio"]
  });
 } else {
  chrome.contextMenus.create({
   id: "download_page",
   title: "Add page to JDownloader",
   contexts: ["page"]
  });
  chrome.contextMenus.create({
   id: "download_link",
   title: "Add link to JDownloader",
   contexts: ["link"]
  });
  chrome.contextMenus.create({
   id: "download_selection",
   title: "Add selection to JDownloader",
   contexts: ["selection"]
  });
  chrome.contextMenus.create({
   id: "download_image",
   title: "Add image to JDownloader",
   contexts: ["image"]
  });
  chrome.contextMenus.create({
   id: "download_video",
   title: "Add video to JDownloader",
   contexts: ["video"]
  });
  chrome.contextMenus.create({
   id: "download_audio",
   title: "Add audio to JDownloader",
   contexts: ["audio"]
  });
 }
}

// ============================================================
// Context menu click handler — adds to request queue + opens toolbar
// ============================================================
chrome.contextMenus.onClicked.addListener((info, tab) => {
 if (!tab || !tab.id) return;
 console.log("Background: Context menu click:", info.menuItemId);

 if (DIRECT_SEND_ENABLED) {
  handleDirectContextSend(info, tab);
  return;
 }

 switch (info.menuItemId) {
  case "simple_menu_item":
   if (info.selectionText) {
    // For selection, send message to content script to get full selection
    chrome.tabs.sendMessage(tab.id, { action: "get-selection", tabId: tab.id });
   } else if (info.linkUrl) {
    addLinkToRequestQueue(info.linkUrl, tab);
   } else if (info.srcUrl) {
    addLinkToRequestQueue(info.srcUrl, tab);
   } else {
    addPageToRequestQueue(tab);
   }
   break;
  case "download_page":
   addPageToRequestQueue(tab);
   break;
  case "download_link":
   if (info.linkUrl) addLinkToRequestQueue(info.linkUrl, tab);
   break;
  case "download_selection":
   chrome.tabs.sendMessage(tab.id, { action: "get-selection", tabId: tab.id });
   break;
  case "download_image":
  case "download_video":
  case "download_audio":
   if (info.srcUrl) addLinkToRequestQueue(info.srcUrl, tab);
   break;
 }
});

// ============================================================
// Storage change listeners
// ============================================================
chrome.storage.onChanged.addListener((changes) => {
 if (changes.myjd_connection_state) {
  state.isConnected = changes.myjd_connection_state.newValue.isConnected;
  updateBadge();
 }
 if (changes[STORAGE_KEYS.CONTEXT_MENU_SIMPLE]) {
  settings[STORAGE_KEYS.CONTEXT_MENU_SIMPLE] = changes[STORAGE_KEYS.CONTEXT_MENU_SIMPLE].newValue;
  initMenuItems();
 }
 if (changes[STORAGE_KEYS.CLICKNLOAD_ACTIVE]) {
  if (changes[STORAGE_KEYS.CLICKNLOAD_ACTIVE].newValue) addCnlInterceptor();
  else removeCnlInterceptor();
 }
 if (changes[STORAGE_KEYS.DEFAULT_PREFERRED_JD]) {
  settings[STORAGE_KEYS.DEFAULT_PREFERRED_JD] = changes[STORAGE_KEYS.DEFAULT_PREFERRED_JD].newValue;
 }
});

// ============================================================
// DeclarativeNetRequest for CNL
// ============================================================
function removeCnlInterceptor() {
 chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [1, 2] }).catch(() => {});
}

function addCnlInterceptor() {
 const rules = [
  { id: 1, priority: 1, action: { type: "allow" }, condition: { urlFilter: ".*localhost:9666.*", resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest"] } },
  { id: 2, priority: 1, action: { type: "allow" }, condition: { urlFilter: ".*127\\.0\\.0\\.1:9666.*", resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest"] } }
 ];
 chrome.declarativeNetRequest.updateSessionRules({ addRules: rules }).catch(() => {});
}

// ============================================================
// Message handler — central routing for popup, toolbar, content scripts
// ============================================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
 // Ignore messages intended for offscreen
 if (request.target === 'offscreen') return false;

 // Security: only accept messages from our own extension
 if (sender.id !== chrome.runtime.id) return false;

 const action = request.action;
 console.log("Background message:", action, "from:", sender.tab ? ('tab:' + sender.tab.id) : 'extension');

 // --- Offscreen management ---
 if (action === "check-offscreen") {
  hasOffscreenDocument().then(hasDoc => sendResponse({ exists: hasDoc }));
  return true;
 }

 if (action === "close-offscreen") {
  closeOffscreenDocument().then(() => sendResponse({ closed: true }));
  return true;
 }

 // --- Connection state ---
 if (action === "set-connection-state") {
  state.isConnected = request.data.isConnected;
  updateBadge();
  sendResponse({ status: 'ok' });
  return true;
 }

 // --- Badge update (from popup, which can't access chrome.action) ---
 if (action === "update-badge") {
  try {
   if (request.data && request.data.text !== undefined) {
    chrome.action.setBadgeText({ text: request.data.text });
   }
   if (request.data && request.data.color !== undefined) {
    chrome.action.setBadgeBackgroundColor({ color: request.data.color });
   }
   sendResponse({ status: 'ok' });
  } catch (e) {
   sendResponse({ status: 'error', error: e.message });
  }
  return true;
 }

 // --- Session info (used by popup + toolbar) ---
 if (action === "session-info") {
  chrome.storage.local.get(['myjd_session'], (result) => {
   sendResponse({
    data: {
     isLoggedIn: result.myjd_session ? true : false,
     connectionState: state.isConnected
    }
   });
  });
  return true;
 }

 // --- Wake check ---
 if (action === "wake") {
  sendResponse({ awake: true });
  return true;
 }

 // --- CONNECTION_STATE_CHANGE broadcast from popup's MyjdService ---
 if (action === "CONNECTION_STATE_CHANGE") {
  // Update internal state
  if (request.data === "CONNECTED") {
   state.isConnected = true;
  } else if (request.data === "DISCONNECTED") {
   state.isConnected = false;
  }
  updateBadge();
  sendResponse({ status: 'ok' });
  return true;
 }

 // ============================================================
 // Request queue handlers (for toolbar add-links flow)
 // ============================================================

 // Return the request queue for a specific tab
 if (action === "link-info") {
  (async () => {
   await queueReady;
   let tabId = String(request.data);
   let queue = requestQueue[tabId] || [];
   sendResponse({ data: queue });
  })();
  return true;
 }

 // Remove a specific request from the queue
 if (action === "remove-request") {
  if (request.data && request.data.tabId && request.data.requestId) {
   let tabId = String(request.data.tabId);
   if (requestQueue[tabId]) {
    requestQueue[tabId] = requestQueue[tabId].filter(r => r.id !== request.data.requestId);
    persistQueue();
   }
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 // Remove all requests for a tab
 if (action === "remove-all-requests") {
  if (request.data && request.data.tabId) {
   delete requestQueue[String(request.data.tabId)];
   persistQueue();
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 // Forward close-toolbar message to the content script in the tab
 if (action === "close-in-page-toolbar") {
  if (request.data && request.data.tabId) {
   let tabId = parseInt(request.data.tabId);
   chrome.tabs.sendMessage(tabId, { action: "close-in-page-toolbar" }).catch(() => {});
   delete requestQueue[String(tabId)];
   persistQueue();
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 // Content script injection acknowledgement
 if (action === "tab-contentscript-injected") {
  sendResponse({ status: 'ok' });
  return true;
 }

 // ============================================================
 // Device polling (from popup's DeviceController)
 // ============================================================
 if (action === "device-poll") {
  // In MV3, device polling happens in the popup's MyjdService directly.
  // Acknowledge the message to prevent errors.
  sendResponse({ status: 'ok' });
  return true;
 }

 if (action === "device-poll-start" || action === "device-poll-stop") {
  sendResponse({ status: 'ok' });
  return true;
 }

 // ============================================================
 // API operations — forwarded to offscreen document
 // ============================================================

 // Device list
 if (action === "devices-pull") {
  sendToOffscreen('offscreen-get-devices').then(result => {
   // Return in format expected by both ToolbarController and ConnectedController
   // ToolbarController expects result.data to be the device array
   // ConnectedController expects result.result.devices or result.devices
   if (result.devices) {
    sendResponse({ data: { devices: result.devices, error: false } });
   } else {
    sendResponse({ data: result });
   }
  }).catch(err => {
   sendResponse({ error: err.message || 'Failed to get devices' });
  });
  return true;
 }

 // Login
 if (action === "login") {
  let creds = request.data;
  sendToOffscreen('offscreen-login', { credentials: creds }).then(result => {
   sendResponse({ data: result });
  }).catch(err => {
   sendResponse({ error: err.message });
  });
  return true;
 }

 // Whoami
 if (action === "whoami") {
  sendToOffscreen('offscreen-whoami').then(result => {
   sendResponse(result);
  }).catch(err => {
   sendResponse({ error: err.message });
  });
  return true;
 }

 // Logout
 if (action === "logout") {
  sendToOffscreen('offscreen-logout').then(result => {
   sendResponse(result);
  }).catch(err => {
   sendResponse({ error: err.message });
  });
  return true;
 }

 // Add link
 if (action === "add-link") {
  const device = request.data ? request.data.device : request.device;
  const query = request.data ? request.data.query : request.query;
  sendToOffscreen('offscreen-add-link', { deviceId: device?.id, query }).then(result => {
   sendResponse(result);
  }).catch(err => {
   sendResponse({ error: err.message });
  });
  return true;
 }

 // Add CNL
 if (action === "add-cnl") {
  const device = request.data ? request.data.device : request.device;
  const query = request.data ? request.data.query : request.query;
  sendToOffscreen('offscreen-add-cnl', { deviceId: device?.id, query }).then(result => {
   sendResponse(result);
  }).catch(err => {
   sendResponse({ error: err.message });
  });
  return true;
 }

 // Send feedback
 if (action === "send-feedback") {
  sendResponse({ status: 'ok' });
  return true;
 }

 // ============================================================
 // CNL captured from content script
 // ============================================================
 if (action === "cnl-captured") {
  console.log("Background: CNL captured:", request.data);
  handleCnlCaptured(request.data);
  sendResponse({ status: 'cnl-received' });
  return true;
 }

 // ============================================================
 // Autograbber status check from content script
 // ============================================================
 if (action === "is-active-on-tab") {
  sendResponse({ data: { active: false } });
  return true;
 }

 // ============================================================
 // Selection from content script
 // ============================================================
 if (action === "selection-result") {
  if (request.data && request.data.text && sender.tab) {
   if (DIRECT_SEND_ENABLED) {
    sendLinksDirectlyToJDownloader(request.data.text, sender.tab)
     .then(result => showDirectSendFeedback('Sélection envoyée vers ' + (result.device.name || 'JDownloader')))
     .catch(e => showDirectSendFeedback(e.message || String(e), true));
   } else {
    addLinkToRequestQueue(request.data.text, sender.tab);
   }
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 // ============================================================
 // CAPTCHA tab tracking and message handling
 // ============================================================

 // MYJD CAPTCHA: prepare tab (write session storage, add CSP rule, navigate)
 if (action === "myjd-prepare-captcha-tab") {
  (async () => {
   try {
    let tabId = request.data.tabId;
    let jobDetails = request.data.jobDetails;
    await chrome.storage.session.set({ myjd_captcha_job: jobDetails });
    addCspStrippingRule(tabId);
    chrome.tabs.update(tabId, { url: jobDetails.targetUrl + '#rc2jdt' });
    activeCaptchaTabs[tabId] = {
     callbackUrl: 'MYJD',
     captchaId: jobDetails.captchaId,
     captchaType: jobDetails.captchaType,
     hoster: jobDetails.hoster,
     detectedAt: Date.now()
    };
    console.log('Background: MYJD CAPTCHA tab prepared:', tabId, jobDetails.hoster);
    sendResponse({ status: 'ok' });
   } catch (err) {
    console.error('Background: Failed to prepare MYJD CAPTCHA tab:', err);
    sendResponse({ status: 'error', error: err.message });
   }
  })();
  return true;
 }

 // MYJD CAPTCHA: execute invisible/v3 CAPTCHA in MAIN world
 if (action === "myjd-captcha-execute") {
  if (sender.tab) {
   chrome.scripting.executeScript({
    target: { tabId: sender.tab.id },
    world: 'MAIN',
    args: [request.data.siteKey, request.data.v3action],
    func: function(siteKey, v3action) {
     if (typeof grecaptcha !== 'undefined') {
      grecaptcha.ready(function() {
       var opts = v3action ? { action: v3action } : {};
       grecaptcha.execute(siteKey, opts);
      });
     } else if (typeof hcaptcha !== 'undefined') {
      hcaptcha.execute();
     }
    }
   }).catch(function(err) {
    console.error('Background: Failed to execute CAPTCHA in MAIN world:', err);
   });
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 // captcha-can-close: close sender tab (fallback for window.close())
 if (action === "captcha-can-close") {
  if (sender.tab) {
   chrome.tabs.remove(sender.tab.id, function() {
    if (chrome.runtime.lastError) { /* ignore */ }
   });
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 if (action === "captcha-tab-detected") {
  if (sender.tab) {
   activeCaptchaTabs[sender.tab.id] = {
    callbackUrl: request.data.callbackUrl,
    captchaType: request.data.captchaType,
    hoster: request.data.hoster,
    captchaId: request.data.captchaId,
    detectedAt: Date.now()
   };
   console.log('Background: CAPTCHA tab detected:', sender.tab.id, request.data.captchaType);
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 if (action === "captcha-solved") {
  if (sender.tab) {
   delete activeCaptchaTabs[sender.tab.id];
  }
  if (request.data.callbackUrl === 'MYJD' && request.data.captchaId) {
   // MYJD flow: route solution through my.jdownloader.org tabs
   chrome.tabs.query({
    url: ['http://my.jdownloader.org/*', 'https://my.jdownloader.org/*']
   }, function(tabs) {
    if (tabs && tabs.length > 0) {
     for (var i = 0; i < tabs.length; i++) {
      chrome.tabs.sendMessage(tabs[i].id, {
       name: 'response',
       type: 'myjdrc2',
       data: { captchaId: request.data.captchaId, token: request.data.token }
      }, function() { /* ignore errors */ });
     }
    }
   });
   // Auto-close sender tab and clean up CSP rule
   if (sender.tab) {
    removeCspStrippingRule(sender.tab.id);
    setTimeout(function() {
     chrome.tabs.remove(sender.tab.id, function() {
      if (chrome.runtime.lastError) { /* ignore */ }
     });
    }, 2000);
   }
  } else if (request.data.callbackUrl && request.data.callbackUrl !== 'MYJD') {
   // Localhost flow: submit token via HTTP GET
   var solveRequest = new XMLHttpRequest();
   solveRequest.open('GET', request.data.callbackUrl + '&do=solve&response=' + encodeURIComponent(request.data.token), true);
   solveRequest.setRequestHeader('X-Myjd-Appkey', 'webextension-' + chrome.runtime.getManifest().version);
   solveRequest.timeout = 10000;
   solveRequest.onload = function() {
    console.log('Background: CAPTCHA token submitted to JDownloader');
    if (sender.tab) {
     setTimeout(function() {
      chrome.tabs.remove(sender.tab.id, function() {
       if (chrome.runtime.lastError) { /* ignore - tab may already be closed */ }
      });
     }, 2000);
    }
   };
   solveRequest.ontimeout = function() {
    console.error('Background: CAPTCHA solve request timed out for', request.data.callbackUrl);
   };
   solveRequest.send();
  } else {
   console.log('Background: CAPTCHA token captured (no JDownloader callback):', request.data.token.substring(0, 20) + '...');
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 if (action === "captcha-skip") {
  if (sender.tab) {
   delete activeCaptchaTabs[sender.tab.id];
  }
  if (request.data.callbackUrl === 'MYJD' && request.data.captchaId) {
   // MYJD flow: send tab-closed to my.jdownloader.org tabs
   chrome.tabs.query({
    url: ['http://my.jdownloader.org/*', 'https://my.jdownloader.org/*']
   }, function(tabs) {
    if (tabs && tabs.length > 0) {
     for (var i = 0; i < tabs.length; i++) {
      chrome.tabs.sendMessage(tabs[i].id, {
       name: 'tab-closed',
       type: 'myjdrc2',
       data: { captchaId: request.data.captchaId }
      }, function() { /* ignore errors */ });
     }
    }
   });
   // Close sender tab and clean up CSP rule
   if (sender.tab) {
    removeCspStrippingRule(sender.tab.id);
    setTimeout(function() {
     chrome.tabs.remove(sender.tab.id, function() {
      if (chrome.runtime.lastError) { /* ignore */ }
     });
    }, 2000);
   }
  } else if (request.data.callbackUrl && request.data.callbackUrl !== 'MYJD') {
   // Localhost flow: send skip via HTTP GET
   var skipRequest = new XMLHttpRequest();
   skipRequest.open('GET', request.data.callbackUrl + '&do=skip&skiptype=' + request.data.skipType, true);
   skipRequest.setRequestHeader('X-Myjd-Appkey', 'webextension-' + chrome.runtime.getManifest().version);
   skipRequest.timeout = 10000;
   skipRequest.onload = function() {
    console.log('Background: CAPTCHA skip sent to JDownloader, type:', request.data.skipType);
    if (sender.tab) {
     setTimeout(function() {
      chrome.tabs.remove(sender.tab.id, function() {
       if (chrome.runtime.lastError) { /* ignore - tab may already be closed */ }
      });
     }, 2000);
    }
   };
   skipRequest.send();
  } else {
   console.log('Background: CAPTCHA skip captured (no JDownloader callback), type:', request.data.skipType);
  }
  sendResponse({ status: 'ok' });
  return true;
 }

 // Default: acknowledge unknown actions
 console.log("Background: Unhandled action:", action);
 sendResponse({ forwarded: true, action: action });
 return true;
});

// ============================================================
// CNL handling
// ============================================================
let cnlRequestQueue = [];

async function handleCnlCaptured(cnlData) {
 cnlRequestQueue.push({
  type: cnlData.type,
  url: cnlData.url,
  formData: cnlData.formData,
  sourceUrl: cnlData.sourceUrl,
  timestamp: cnlData.timestamp || Date.now()
 });

 await chrome.storage.local.set({ 'cnl_queue': cnlRequestQueue });

 try {
  const settings = await chrome.storage.local.get(['ADD_LINKS_DIALOG_ACTIVE', 'DEFAULT_PREFERRED_JD']);
  const shouldOpenPopup = settings.ADD_LINKS_DIALOG_ACTIVE !== false;

  if (shouldOpenPopup) {
   await chrome.storage.local.set({ 'cnl_pending': true });
  } else {
   await processCnlViaOffscreen(cnlData);
  }
 } catch(e) {
  console.error("Background: Failed to handle CNL:", e);
 }
}

async function processCnlViaOffscreen(cnlData) {
 await createOffscreenDocument();
 const query = {
  links: cnlData.formData?.crypted || cnlData.formData?.urls || '',
  sourceUrl: cnlData.sourceUrl
 };
 const result = await sendToOffscreen('offscreen-add-cnl', { query: query });
 console.log("Background: CNL processed:", result);
 return result;
}

// ============================================================
// CAPTCHA tab tracking (in-memory, NOT persisted)
// ============================================================
let activeCaptchaTabs = {};

// ============================================================
// Clean up request queue and CAPTCHA tabs when tabs are closed
// ============================================================
chrome.tabs.onRemoved.addListener((tabId) => {
 // Existing: clean up request queue
 delete requestQueue[String(tabId)];
 persistQueue();

 // Always clean up CSP rules for closed tabs
 removeCspStrippingRule(tabId);

 // CAPTCHA: send skip on tab close (CAP-07)
 if (activeCaptchaTabs[tabId]) {
  var info = activeCaptchaTabs[tabId];
  delete activeCaptchaTabs[tabId];
  if (info.callbackUrl === 'MYJD') {
   // MYJD flow: send tab-closed to my.jdownloader.org tabs
   chrome.tabs.query({
    url: ['http://my.jdownloader.org/*', 'https://my.jdownloader.org/*']
   }, function(tabs) {
    if (tabs && tabs.length > 0) {
     for (var i = 0; i < tabs.length; i++) {
      chrome.tabs.sendMessage(tabs[i].id, {
       name: 'tab-closed',
       type: 'myjdrc2',
       data: { captchaId: info.captchaId }
      }, function() { /* ignore errors */ });
     }
    }
   });
   console.log('Background: MYJD CAPTCHA tab closed, sent tab-closed for', info.hoster);
  } else if (info.callbackUrl) {
   var httpRequest = new XMLHttpRequest();
   httpRequest.open('GET', info.callbackUrl + '&do=skip&skiptype=single', true);
   httpRequest.setRequestHeader('X-Myjd-Appkey', 'webextension-' + chrome.runtime.getManifest().version);
   httpRequest.timeout = 10000;
   httpRequest.send();
   console.log('Background: CAPTCHA tab closed, sent skip(single) for', info.hoster);
  } else {
   console.log('Background: CAPTCHA tab closed (no JDownloader callback) for', info.hoster);
  }
 }
});

// ============================================================
// Keep alive + init
// ============================================================
chrome.alarms.create('keepAlive', { periodInMinutes: 4 });
chrome.alarms.onAlarm.addListener(() => {
 console.log("Background: Keepalive alarm");
});

chrome.runtime.onInstalled.addListener(initSettings);
chrome.runtime.onStartup.addListener(initSettings);

initSettings();
console.log("Background ready");
